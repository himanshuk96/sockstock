microservices-demo documentation
================================

> This directory contains the deployment and internal documentation.
It is published at [microservices-demo.github.io](https://microservices-demo.github.io)


## Getting started

There is a [docker-compose](https://docs.docker.com/compose/) included for
local development, use the following command to start it:

```
docker-compose up
```
